#!/usr/bin/env python3
"""
Serve static files with FastAPI from directories
static and templates
"""

from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles

app = FastAPI()

app.mount("/templates", StaticFiles(directory="templates"), name="templates")

@app.get("/", response_class=HTMLResponse)
async def read_root():
    # read index.html from templates directory
    with open("templates/index.html") as f:
        return HTMLResponse(content=f.read(), status_code=200)
    
if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
