flowchart TD
    U[USER] ==>|HTTP| S(STATIC FILES)
    U ==> | REST Transfer requests | C{COORDINATOR}
    S ==> U
    C ==> U
    C -->|Request & validate account info and balance | A[accinfo]
    A --> C
    C -->|Exchange rate info| E[exchange_rate]
    E --> C
    C -->|Nofification| N[notification]
