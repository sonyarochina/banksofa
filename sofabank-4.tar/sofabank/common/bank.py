
from pydantic import BaseModel
import sqlite3
import redis
import json
import random
# datetime
from datetime import datetime

def random_id():
    """
    32-character random string
    """
    return ''.join(random.choices('0123456789abcdef', k=32))

class BankInfo:
    def __init__(self):
        self.dbfile = 'db/sofabank.db'

    def get_dbfile(self):
        return self.dbfile

class Account(BaseModel):
    account_id: int
    account_name: str
    account_balances: dict
    active: bool

class AccountDB:
    def __init__(self):
        self.sqlite_file = BankInfo().get_dbfile()
        self.conn = sqlite3.connect(self.sqlite_file)
        self.c = self.conn.cursor()
    
    def get_all_accounts(self):
        self.c.execute("SELECT * FROM accounts")
        accounts = self.c.fetchall()
        accounts_list = []
        for account in accounts:
            self.c.execute("SELECT * FROM balances WHERE account_id=?", (account[0],))
            balances = self.c.fetchall()
            account_balances = {}
            for balance in balances:
                account_balances[balance[1]] = balance[2]
            if account[3] == 1:
                accounts_list.append({
                    'account_id': account[0],
                    'account_name': account[1],
                    'account_balances': account_balances,
                    'email': account[4]
                })
        return accounts_list

    def get_account_info(self, account_id: int):
        self.c.execute("SELECT * FROM accounts WHERE account_id=?", (account_id,))
        account = self.c.fetchone()
        if account is None:
            return None
        self.c.execute("SELECT * FROM balances WHERE account_id=?", (account_id,))
        balances = self.c.fetchall()
        account_balances = {}
        for balance in balances:
            account_balances[balance[1]] = balance[2]

        return {
            'account_id': account[0],
            'account_name': account[1],
            'account_balances': account_balances,
            'active': account[3],
            'email': account[4]
        }

    def __del__(self):
        self.conn.close()

class AccountInfoRequest:
    def __init__(self):
        self.rconn = redis.Redis(host='localhost', port=6379, db=0)
        self.tx_channel = 'account_info'
        self.rx_channel = random_id()
    
    def request_info(self, account_id: int, currencysrc: str = None, amount: float = None):
        # subscribe to the channel where we will receive the answer
        self.p = self.rconn.pubsub()
        self.p.subscribe(self.rx_channel)
        # publish the request
        request = {
            'account_id': account_id,
            'currencysrc': currencysrc,
            'amount': amount,
            'channel': self.rx_channel
        }
        self.rconn.publish(self.tx_channel, json.dumps(request))
        # wait for the answer
        for message in self.p.listen():
            if message['type'] == 'message':
                self.p.close()
                return json.loads(message['data'])
        self.p.close()

class ExchangeRateInfo:
    def __init__(self):
        self.rconn = redis.Redis(host='localhost', port=6379, db=0)
        self.tx_channel = 'exchange_rate'
        self.rx_channel = random_id()

    def request_rate(self, currencysrc: str, currencydst: str, amount: float):
        # subscribe to the channel where we will receive the answer
        self.p = self.rconn.pubsub()
        self.p.subscribe(self.rx_channel)
        # publish the request
        request = {
            'currencysrc': currencysrc,
            'currencydst': currencydst,
            'amount': amount,
            'channel': self.rx_channel
        }
        self.rconn.publish(self.tx_channel, json.dumps(request))
        # wait for the answer
        for message in self.p.listen():
            if message['type'] == 'message':
                self.p.close()
                return json.loads(message['data'])
        self.p.close()

class NotificationRequest:
    def __init__(self):
        self.rconn = redis.Redis(host='localhost', port=6379, db=0)
        self.tx_channel = 'notification_channel'

    def send_notification(self, to_email: str, subject: str, body: str):
        request = {
            'email': to_email,
            'subject': subject,
            'body': body
        }
        self.rconn.publish(self.tx_channel, json.dumps(request))


class Transaction:
    def __init__(self):
        self.sqlite_file = BankInfo().get_dbfile()
        self.conn = sqlite3.connect(self.sqlite_file)
        self.c = self.conn.cursor()

    def transfer(self, from_account: int, to_account: int, amount: float, amountdst: float, currencysrc: str, currencydst: str):
        """We define transaction to be safe from race conditions and etc."""
        self.c.execute("BEGIN TRANSACTION")
        # verify if the source account exists and have this currency account and enough amount
        self.c.execute("SELECT * FROM balances WHERE account_id=? AND currency=? AND balance>=?", (from_account, currencysrc, amount))
        from_balance = self.c.fetchone()
        if from_balance is None:
            self.c.execute("ROLLBACK")
            return False
        # verify if the destination account exists and have this currency account
        self.c.execute("SELECT * FROM balances WHERE account_id=? AND currency=?", (to_account, currencydst))
        to_balance = self.c.fetchone()
        if to_balance is None:
            self.c.execute("ROLLBACK")
            return False
        self.c.execute("UPDATE balances SET balance=balance-? WHERE account_id=? AND currency=?", (amount, from_account, currencysrc))
        self.c.execute("UPDATE balances SET balance=balance+? WHERE account_id=? AND currency=?", (amountdst, to_account, currencydst))
        # Add to transactions table
        datetime_now = datetime.now().isoformat()
        self.c.execute("INSERT INTO transactions (src_account_id, dest_account_id, currency, amount, rate, timestamp) VALUES (?, ?, ?, ?, ?, ?)", (from_account, to_account, currencysrc, amount, amountdst/amount, datetime_now))
        self.c.execute("COMMIT")
        return True

    def __del__(self):
        self.conn.close()



