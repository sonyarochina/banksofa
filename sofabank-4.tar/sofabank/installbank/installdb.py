#!/usr/bin/env python3
"""
Initializes the SofaBank database
"""

import sqlite3
import os
import redis

class CleanRedis:
    def __init__(self):
        self.clean_redis()

    def clean_redis(self):
        """
        Cleans the redis database
        """

        # Connect to redis
        r = redis.Redis(host='localhost', port=6379, db=0)

        # delete key exchange_rate
        r.delete('exchange_rate')

        # Flush the database
        r.flushdb()

        # Close the connection
        r.close()

class NewDatabase:
    def __init__(self, dbfile):
        self.dbfile = dbfile
        self.delete_db()
        self.init_db()
        self.insert_example_data()

    def init_db(self):
        """
        Initializes the database

        accounts table>
        account_id: int
        name: text
        username: text
        active: int

        transactions table>
        transaction_id: int
        src_account_id: int
        dest_account_id: int
        currency: text
        amount: float

        balances table>
        account_id: int
        currency: text
        balance: float
        """

        # Create the database
        conn = sqlite3.connect(self.dbfile)
        c = conn.cursor()

        # Create the accounts table
        c.execute('''CREATE TABLE accounts
                     (account_id INTEGER PRIMARY KEY, name TEXT, username TEXT, active INTEGER, email TEXT)''')

        # Create the transactions table
        c.execute('''CREATE TABLE transactions
                    (transaction_id INTEGER PRIMARY KEY, src_account_id INTEGER, dest_account_id INTEGER, currency TEXT, amount REAL, rate REAL, timestamp TEXT)''')

        # Create the balances table
        c.execute('''CREATE TABLE balances
                     (account_id INTEGER, currency TEXT, balance REAL)''')

        # Commit the changes
        conn.commit()

        # Close the connection
        conn.close()

    def insert_example_data(self):
        """
        Inserts example data into the database
        """

        # Connect to the database
        conn = sqlite3.connect(self.dbfile)
        c = conn.cursor()

        # Insert example data into the accounts table
        c.execute("INSERT INTO accounts (name, username, active, email) VALUES ('Alice', 'alice', 1, 'alice@alice.com')")
        c.execute("INSERT INTO accounts (name, username, active, email) VALUES ('Biden', 'Biden', 1, 'bob@bob.com')")
        c.execute("INSERT INTO accounts (name, username, active, email) VALUES ('Sofa', 'Sofa', 1, 'sofa@sofa.gov')")
        c.execute("INSERT INTO accounts (name, username, active, email) VALUES ('Trump', 'Trump', 0, 'trump@whitehouse.gov')")

        # Insert example data into the transactions table
        c.execute("INSERT INTO transactions (src_account_id, dest_account_id, currency, amount, rate, timestamp) VALUES (1, 2, 'USD', 100.0, 1.0, '2021-01-01 00:00:00')")

        # Insert example data into the balances table
        c.execute("INSERT INTO balances (account_id, currency, balance) VALUES (1, 'USD', 100.0)")
        c.execute("INSERT INTO balances (account_id, currency, balance) VALUES (1, 'RUB', 10000.0)")
        c.execute("INSERT INTO balances (account_id, currency, balance) VALUES (2, 'USD', 0.0)")
        c.execute("INSERT INTO balances (account_id, currency, balance) VALUES (2, 'RUB', 0.0)")
        c.execute("INSERT INTO balances (account_id, currency, balance) VALUES (3, 'USD', 1000000.0)")
        c.execute("INSERT INTO balances (account_id, currency, balance) VALUES (3, 'RUB', 100000000.0)")
        c.execute("INSERT INTO balances (account_id, currency, balance) VALUES (4, 'USD', 0.0)")
        c.execute("INSERT INTO balances (account_id, currency, balance) VALUES (4, 'RUB', 10000.0)")

        # Commit the changes
        conn.commit()

        # Close the connection
        conn.close()

    def delete_db(self):
        """
        Deletes the database
        """

        # Check if the database exists
        if os.path.exists(self.dbfile):
            os.remove(self.dbfile)
