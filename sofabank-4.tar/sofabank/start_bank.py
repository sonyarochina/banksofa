#!/usr/bin/env python3

from installbank.installdb import NewDatabase, CleanRedis
from common.bank import BankInfo
import os
import subprocess
import sys


microservices = [
    "microservice_accinfo.py",
    "microservice_static.py",
    "microservice_coordinator.py",
    "microservice_exchange_rate.py",
    "microservice_notification.py",
]

def main():
    binfo = BankInfo()
    DBFILE = binfo.get_dbfile()
    if os.path.exists(DBFILE):
        print(f"Database file {DBFILE} already exists, using it")
    else:
        NewDatabase(DBFILE)
        CleanRedis()
        print(f"Database file {DBFILE} created")

    # launch microservices in separate processes
    processes = []
    for ms in microservices:
        p = subprocess.Popen([sys.executable, ms])
        processes.append(p)
        print(f"Launched {ms}")

    # wait for all processes to finish
    for p in processes:
        p.wait()


if __name__ == '__main__':
    main()
