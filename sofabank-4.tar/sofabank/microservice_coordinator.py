#!/usr/bin/env python3
"""
Transaction coordinator/initiator microservice
"""

from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import redis
from common.bank import BankInfo, AccountInfoRequest, ExchangeRateInfo, Transaction, NotificationRequest, AccountDB
import json

app = FastAPI()

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/", response_class=HTMLResponse)
async def read_root():
    return """
    <html>
        <head>
            <title>Transaction coordinator</title>
        </head>
        <body>
            <h1>Transaction coordinator</h1>
            <p>Use the API to initiate transactions</p>
        </body>
    </html>
    """

@app.get("/accounts", response_class=JSONResponse)
async def get_accounts():
    acc = AccountDB()
    accounts = acc.get_all_accounts()
    return accounts

@app.get("/accinfo/{account}", response_class=JSONResponse)
async def get_account_info(account: int):
    acc = AccountInfoRequest()
    accinfo = acc.request_info(account)
    if accinfo is None:
        return JSONResponse(content={"error": f"Account {account} not found"}, status_code=404)
    return json.dumps(accinfo)


@app.get("/exchange/{currencysrc}/{currencydst}", response_class=JSONResponse)
async def get_exchange_rate(currencysrc: str, currencydst: str):
    amount = 1.0
    einfo = ExchangeRateInfo()
    rate = einfo.request_rate(currencysrc, currencydst, amount)
    if rate is None:
        return JSONResponse(content={"error": f"Cannot get exchange rate"}, status_code=500)
    return json.dumps({"rate": rate})

class TransferRequest(BaseModel):
    sender: str
    receiver: str
    amount: float

@app.post("/transfer", response_class=HTMLResponse)
async def do_transfer(transfer: TransferRequest):
    # parse accounts (sender/receiver) as account_id:currency
    sender = transfer.sender.split(':')
    receiver = transfer.receiver.split(':')
    if len(sender) != 2 or len(receiver) != 2:
        return JSONResponse(content={"error": f"Invalid account format"}, status_code=400)
    from_account = int(sender[0])
    to_account = int(receiver[0])
    currencysrc = sender[1]
    currencydst = receiver[1]
    if currencysrc == currencydst and from_account == to_account:
        return JSONResponse(content={"error": f"Source and destination accounts are the same"}, status_code=400)
    
    if from_account < 0 or to_account < 0:
        return JSONResponse(content={"error": f"Invalid account number"}, status_code=400)
    
    if transfer.amount <= 0:
        return JSONResponse(content={"error": f"Invalid amount"}, status_code=400)


    amountsrc = transfer.amount
    # Allowed, we might just exchange rate
    #if from_account == to_account:
    #    return JSONResponse(content={"error": f"Source and destination accounts are the same"}, status_code=400)

    src = AccountInfoRequest()
    srcinfo = src.request_info(from_account, currencysrc, amountsrc)
    # any error?
    if srcinfo is None:
        return JSONResponse(content={"error": f"Account {from_account} not found"}, status_code=404)
    if srcinfo['error'] is not None:
        return JSONResponse(content={"error": srcinfo['error']}, status_code=400)
    srcinfo = srcinfo['account']
    if srcinfo is None:
        return JSONResponse(content={"error": f"Account {from_account} not found"}, status_code=404)
    if not srcinfo['active']:
        return JSONResponse(content={"error": f"Account {from_account} is not active"}, status_code=400)
    if srcinfo['account_balances'][currencysrc] < amountsrc:
        return JSONResponse(content={"error": f"Insufficient funds in account {from_account}"}, status_code=400)
    dst = AccountInfoRequest()
    dstinfo = dst.request_info(to_account)
    dstinfo = dstinfo['account']
    if dstinfo is None:
        return JSONResponse(content={"error": f"Account {to_account} not found"}, status_code=404)
    if not dstinfo['active']:
        return JSONResponse(content={"error": f"Account {to_account} is not active"}, status_code=400)

    einfo = ExchangeRateInfo()
    rate = einfo.request_rate(currencysrc, currencydst, 1.0)
    if rate is None:
        return JSONResponse(content={"error": f"Cannot get exchange rate"}, status_code=500)
    amountdst = amountsrc * rate['rate']

    tr = Transaction()
    tr.transfer(from_account, to_account, amountsrc, amountdst, currencysrc, currencydst)

    nr = NotificationRequest()
    email_src = srcinfo['email']
    email_dst = dstinfo['email']
    nr.send_notification(to_email=email_src, body=f"Transfer of {amountsrc} {currencysrc} to account {to_account} completed", subject="Your transfer completed")
    nr.send_notification(to_email=email_dst, body=f"Transfer of {amountdst} {currencydst} from account {from_account} completed", subject="Incoming transfer completed")

    msg = f"Transfer from account {from_account} to account {to_account} completed. New {from_account} balance is {srcinfo['account_balances'][currencysrc] - amountsrc} {currencysrc}"
    msg += f". New {to_account} balance is {dstinfo['account_balances'][currencydst] + amountdst} {currencydst}"

    return JSONResponse(content={"message": msg})

    
if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)
