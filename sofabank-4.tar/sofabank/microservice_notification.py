#!/usr/bin/env python3
"""
Receive from redis pub/sub notification_channel
and send emails
"""

import redis
import json
import smtplib
from email.mime.text import MIMEText

def send_email_stub(to_email: str, subject: str, body: str):
    from_email = 'bank@sofabank.ru'
    msg = MIMEText(body)
    msg['Subject'] = subject
    msg['From'] = from_email
    msg['To'] = to_email
    s = smtplib.SMTP('localhost')
    s.sendmail(from_email, [to_email], msg.as_string())
    s.quit()

def send_email(to_email: str, subject: str, body: str):
    """
    Emulate sending email by printing to console
    """
    # save to file for testing
    msg = f"From: bank@sofabank.ru"
    msg += f"To: {to_email}"
    msg += f"Subject: {subject}"
    msg += body
    print(f"Sending email: {msg}")
    # send_email_stub(to_email, subject, body)
    with open('email_log.txt', 'a') as f:
        f.write('---\n')
        f.write(msg)
        f.write('\n')


def main():
    r = redis.Redis(host='localhost', port=6379, db=0)
    p = r.pubsub()
    p.subscribe('notification_channel')
    for message in p.listen():
        if message['type'] == 'message':
            print(f"Received: {message}")
            data = json.loads(message['data'])
            to_email = data['email']
            subject = data['subject']
            body = data['body']
            send_email(to_email, subject, body)
    p.close()
