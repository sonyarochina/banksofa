sequenceDiagram
    participant User
    participant Static
    participant Coordinator
    participant Accinfo
    participant Exchange_rate
    participant Notification
    Note right of User: HTTP protocol    
    User->>Static: Request index page /
    Static->>User: templates/index.html
    User->>Static: Request /style.css
    Static->>User: templates/style.css
    Note left of Coordinator: HTTP/REST protocol    
    User->>Coordinator: Request transfer from A to B in X CUR1 to Y CUR2
    Note right of Coordinator: PUB/SUB protocol
    Coordinator-->>Accinfo: Request account A balance in CUR1
    Accinfo-->>Coordinator: Confirm account A balance in CUR1 and give full info
    Coordinator-->>Accinfo: Request account B info
    Accinfo-->>Coordinator: Confirm account B exist
    Coordinator-->>Exchange_rate: Request exchange rate from CUR1 to CUR2
    Note over Exchange_rate: Check if Redis contains fresh rate, if stale, request over API
    Exchange_rate-->>Coordinator: Return exchange rate
    Note over Coordinator: Create transaction and do the transfer over SQLITE
    Coordinator-->>Notification: Send email to both accounts about transaction
    Coordinator->>User: Transaction OK
