#!/usr/bin/env python3
"""
FastAPI app to get account information of virtual bank from sqlite database

Author: Sofa
"""

import sqlite3
from common.bank import BankInfo, Account, AccountDB
# redis pubsub
import redis
import json

def main():
    print("Starting account information microservice")
    # Connect to sqlite database
    adb = AccountDB()
    # redis pubsub
    r = redis.Redis(host='localhost', port=6379, db=0)
    p = r.pubsub()
    p.subscribe('account_info')
    for message in p.listen():
        if message['type'] == 'message':
            print(f"Received: {message}")
            # account id to search
            data = json.loads(message['data'])
            account_id = data['account_id']
            channel_id = data['channel']
            currencysrc = data['currencysrc']
            amount = data['amount']
            account = adb.get_account_info(account_id)
            answer = {
                'account_id': account_id,
                'account': account,
                'error': None
            }
            # validate if we have enough currency
            funds_enough = False
            if account is not None:
                for curname in account['account_balances']:
                    bal = account['account_balances'][curname]
                    print(f"Checking account balance {curname}: {bal}")
                    if currencysrc == curname:
                        if bal < amount:
                            answer['error'] = f"Insufficient funds: {bal} < {amount}"
                        else:
                            funds_enough = True
                            break
            if not funds_enough:
                answer['error'] = f"Account {account_id} does not have enough funds in {currencysrc}"

            print(f"Publishing answer to channel {channel_id}")
            print(f"Answer: {answer}")
            r.publish(channel_id, json.dumps(answer))
            if account is None:
                print(f"Account {account_id} not found")
            else:
                print(f"Account {account_id} found: {account}")
    p.close()

if __name__ == '__main__':
    main()
