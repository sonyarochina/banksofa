#!/usr/bin/env python3
"""
Retrieve exchange rates from a public API
Cache in Redis X minutes
Answer requests over pubsub

API: https://www.cbr-xml-daily.ru/latest.js
"""

import redis
import requests
import json
import time
from datetime import datetime, timedelta

EXPIRY_SECONDS = 60*30
EXCHANGERATE_KEY = 'exchange_rate'

def get_exchange_rates():
    try:
        req = requests.get('https://www.cbr-xml-daily.ru/latest.js')
        req.raise_for_status()
    except requests.exceptions.HTTPError as err:
        print(err)
        return None
    try:
        data = req.json()
        print(f"Got exchange rates from API: {data}")
        return data
    except json.JSONDecodeError as err:        
        print(err)
        return None
    

def get_cache(currency: str):
    rconn = redis.Redis(host='localhost', port=6379, db=0)
    rate = rconn.get(EXCHANGERATE_KEY)
    if rate is None:
        print("Cannot get exchange rates from redis")
        newrate = get_exchange_rates()
        if newrate is None:
            print("Cannot get exchange rates from API and no cache")
            return None
        curinfo = {
            'exchangeinfo': newrate,
            'timestamp': datetime.now().isoformat()
        }
        rconn.set(EXCHANGERATE_KEY, json.dumps(curinfo), ex=EXPIRY_SECONDS)
        return newrate
    exrate = json.loads(rate)    
    rate = exrate.get('exchangeinfo')
    print(f"Got exchange rates from cache: {rate}")
    return rate


def get_exchange_rate(currencysrc: str, currencydst: str, amount: float):
    ratedata = get_cache(currencysrc)
    rates = ratedata.get('rates')
    if rates is None:
        print("get_exchange_rate(): No exchange rates in cache")
        return None
    if currencysrc == 'RUB':
        ratesrc = 1.0
    else:
        ratesrc = rates.get(currencysrc)

    if currencydst == 'RUB':
        ratedst = 1.0
    else:
        ratedst = rates.get(currencydst)

    if ratesrc is None or ratedst is None:
        print(f"Cannot get exchange rate from {currencysrc} to {currencydst}")
        return None
    
    rate = amount * ratedst / ratesrc
    print(f"Exchange rate from {currencysrc} to {currencydst}: {ratedst / ratesrc}: {rate}")
    return rate

def main():
    rconn = redis.Redis(host='localhost', port=6379, db=0)
    p = rconn.pubsub()
    p.subscribe('exchange_rate')
    for message in p.listen():
        if message['type'] == 'message':
            data = json.loads(message['data'])
            currencysrc = data['currencysrc']
            currencydst = data['currencydst']
            amount = data['amount']
            rate = get_exchange_rate(currencysrc, currencydst, amount)
            if rate is None:
                answer = {
                    'error': 'Cannot get exchange rate',
                    'rate': None
                }
            else:
                answer = {
                    'rate': rate
                }
            print(f"Publishing answer to channel {data['channel']}")
            print(f"Answer: {answer}")
            rconn.publish(data['channel'], json.dumps(answer))
    p.close()

if __name__ == '__main__':
    main()
